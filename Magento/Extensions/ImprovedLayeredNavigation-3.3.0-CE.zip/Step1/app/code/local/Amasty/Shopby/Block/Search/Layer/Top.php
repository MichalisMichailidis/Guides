<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Shopby
 */

class Amasty_Shopby_Block_Search_Layer_Top extends Amasty_Shopby_Block_Search_Layer
{
    protected $_blockPos = Amasty_Shopby_Model_Source_Position::TOP;
}