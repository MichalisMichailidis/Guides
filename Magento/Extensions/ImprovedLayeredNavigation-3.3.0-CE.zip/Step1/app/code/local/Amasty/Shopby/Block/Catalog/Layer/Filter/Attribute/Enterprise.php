<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Shopby
 */


class Amasty_Shopby_Block_Catalog_Layer_Filter_Attribute_Pure extends Enterprise_Search_Block_Catalog_Layer_Filter_Attribute {}
