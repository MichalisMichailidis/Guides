<?php

class Mage_Hellaspay_Block_Info extends Mage_Core_Block_Template
{

}
