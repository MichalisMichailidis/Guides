<?php

class Mage_Hellaspay_Helper_Data extends Mage_Core_Helper_Abstract
{

} 
