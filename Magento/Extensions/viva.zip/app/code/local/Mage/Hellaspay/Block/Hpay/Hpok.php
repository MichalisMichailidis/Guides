<?php

class Mage_Hellaspay_Block_Hpay_Hpok extends Mage_Core_Block_Abstract
{
    protected function _toHtml()
    {
        
    }
}

?>