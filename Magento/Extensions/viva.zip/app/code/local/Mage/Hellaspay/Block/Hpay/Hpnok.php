<?php

class Mage_Hellaspay_Block_Hpay_Hpnok extends Mage_Core_Block_Abstract
{
    protected function _toHtml()
    {

    }
}

?>