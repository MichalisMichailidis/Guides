<?php

class Mage_Hellaspay_Model_Hpay_Request extends Varien_Object 
{
    
}
