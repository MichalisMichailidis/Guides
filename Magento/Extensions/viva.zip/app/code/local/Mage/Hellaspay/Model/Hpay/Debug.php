<?php

class Mage_Paygate_Model_Authorizenet_Debug extends Mage_Core_Model_Abstract 
{
	protected function _construct()
	{
		$this->_init('paygate/authorizenet_debug');
	}
}