<?php

class Mage_Hellaspay_Model_Hpay_Result extends Varien_Object 
{
    
}
