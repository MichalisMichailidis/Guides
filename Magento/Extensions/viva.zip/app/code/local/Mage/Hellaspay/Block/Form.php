<?php

class Mage_Hellaspay_Block_Form extends Mage_Core_Block_Template
{

}
