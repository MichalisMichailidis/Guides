WEB-IT, Internet Business Solutions
site: http://www.webit.bz
email: info@webit.bz

Copyright (c) 2013 WEB-IT
http://www.webit.bz/license.txt

INSTALLATION:
1) Upload the files to their corresponding location on the server (ftp/ssh).
2) Clear Magento cache. 
3) Configure the "Viva Payments" payment module.
4) At your Viva Payments backoffice create a new payment source:

Example with URL rewrite disabled:
Success page: index.php/hellaspay/hpay/hpok/
Failure page: index.php/hellaspay/hpay/hpnok/

Example with URL rewrite enabled:
Success page: hellaspay/hpay/hpok/
Failure page: hellaspay/hpay/hpnok/